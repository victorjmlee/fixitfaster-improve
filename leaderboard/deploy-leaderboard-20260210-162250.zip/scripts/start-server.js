#!/usr/bin/env node
const { spawnSync } = require("child_process");
const port = process.env.PORT || "3000";
const result = spawnSync(
  "npx",
  ["next", "start", "-p", port],
  { stdio: "inherit", env: process.env }
);
process.exit(result.status || 0);
