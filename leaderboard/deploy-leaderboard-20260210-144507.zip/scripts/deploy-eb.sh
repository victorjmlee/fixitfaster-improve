#!/usr/bin/env bash
# 로컬에서 빌드한 뒤 .next 포함해서 EB에 배포 (서버에서는 npm run build 안 함)
set -e

LEADERBOARD_ROOT="$(cd "$(dirname "$0")/.." && pwd)"
REPO_ROOT="$(cd "$LEADERBOARD_ROOT/.." && pwd)"
CONFIG="$REPO_ROOT/.elasticbeanstalk/config.yml"

# config에서 리전/프로필 읽기 (eb와 동일)
REGION="${AWS_REGION:-$(grep -E '^\s*default_region:' "$CONFIG" 2>/dev/null | sed 's/.*: *//' | tr -d ' ')}"
REGION="${REGION:-us-east-1}"
PROFILE="${AWS_PROFILE:-$(grep -E '^\s*profile:' "$CONFIG" 2>/dev/null | sed 's/.*: *//' | tr -d ' ')}"
PROFILE="${PROFILE:-default}"
VERSION_LABEL="leaderboard-$(date +%Y%m%d-%H%M%S)"
ZIP_NAME="deploy-${VERSION_LABEL}.zip"

# application name from EB config
if [[ ! -f "$CONFIG" ]]; then
  echo "ERROR: $CONFIG not found. Run this script from leaderboard/ (fixitfaster/leaderboard)." >&2
  exit 1
fi
APP_NAME=$(grep -E '^\s*application_name:' "$CONFIG" | sed 's/.*: *//' | tr -d ' ')
if [[ -z "$APP_NAME" ]]; then
  echo "ERROR: could not get application_name from $CONFIG" >&2
  exit 1
fi

# environment: first arg, or current from eb status
ENV_NAME="$1"
if [[ -z "$ENV_NAME" ]]; then
  EB_STATUS=$(cd "$REPO_ROOT" && eb status 2>/dev/null || true)
  ENV_NAME=$(echo "$EB_STATUS" | grep -iE "Environment (name)?:?|details for:" | head -1 | sed 's/.*: *//' | tr -d ' ')
  if [[ -z "$ENV_NAME" ]]; then
    echo "Usage: $0 [environment-name]" >&2
    echo "Example: $0 fixitfaster-leaderboard-victorlee" >&2
    echo "Or run 'eb use <env>' from repo root, then run $0 again." >&2
    exit 1
  fi
fi

echo "==> Build (leaderboard)"
cd "$LEADERBOARD_ROOT"
npm run build

echo "==> Create deployment zip (including .next)"
ZIP_PATH="$LEADERBOARD_ROOT/$ZIP_NAME"
rm -f "$ZIP_PATH"
(cd "$LEADERBOARD_ROOT" && zip -r "$ZIP_NAME" . \
  -x "node_modules/*" \
  -x ".git/*" \
  -x ".next/cache/*" \
  -x "*.zip" \
  -x ".env*" \
  -x "data/submissions.json" \
  ) >/dev/null 2>&1

if [[ ! -f "$ZIP_PATH" ]]; then
  echo "ERROR: failed to create zip" >&2
  exit 1
fi
# 배포 번들에 leaderboard predeploy(빌드 없음) 가 들어갔는지 확인
if unzip -l "$ZIP_PATH" 2>/dev/null | grep -q "platform/hooks/predeploy/01_build.sh"; then
  echo "==> Zip contains .platform/hooks/predeploy/01_build.sh (leaderboard, no build)"
else
  echo "WARN: .platform/hooks/predeploy/01_build.sh not found in zip" >&2
fi

echo "==> Get EB S3 bucket (region=$REGION profile=$PROFILE)"
# create-storage-location: 기존 버킷 반환 또는 생성 (describe-storage-location 은 구 CLI 에 없을 수 있음)
BUCKET=$(aws elasticbeanstalk create-storage-location --region "$REGION" --profile "$PROFILE" --query 'S3Bucket' --output text 2>&1) || true
if [[ -z "$BUCKET" ]] || [[ "$BUCKET" == *"Error"* ]] || [[ "$BUCKET" == *"error"* ]] || [[ "$BUCKET" == *"invalid"* ]]; then
  echo "ERROR: could not get EB storage bucket." >&2
  echo "  Region: $REGION  Profile: $PROFILE" >&2
  echo "  AWS output: $BUCKET" >&2
  exit 1
fi

S3_KEY="eb-$APP_NAME/$ZIP_NAME"
echo "==> Upload to s3://$BUCKET/$S3_KEY"
aws s3 cp "$ZIP_PATH" "s3://$BUCKET/$S3_KEY" --region "$REGION" --profile "$PROFILE"

echo "==> Create application version: $VERSION_LABEL"
aws elasticbeanstalk create-application-version \
  --application-name "$APP_NAME" \
  --version-label "$VERSION_LABEL" \
  --source-bundle "S3Bucket=$BUCKET,S3Key=$S3_KEY" \
  --region "$REGION" \
  --profile "$PROFILE"

echo "==> Deploy to environment: $ENV_NAME"
aws elasticbeanstalk update-environment \
  --environment-name "$ENV_NAME" \
  --version-label "$VERSION_LABEL" \
  --region "$REGION" \
  --profile "$PROFILE"

rm -f "$ZIP_PATH"
echo "==> Done. Monitor: eb status (from repo root) or AWS Console."
